import React from 'react'

const Movie = () => {
  return (
    <div>movie</div>
  )
}

export default Movie